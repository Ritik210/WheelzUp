﻿


[System.Serializable]
public class Questions 
{
    public string ques;
    public string answer;
   
}
