﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using UnityEngine.UI;

public class ScoreSystem : MonoBehaviourPunCallbacks
{
    public int score;
    PlayerSetup playerSetup;

    public Text p1Score;
    public Text p2Score;
    public int p1Scores = 0;
    public int p2Scores = 0;

    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        playerSetup = FindObjectOfType<PlayerSetup>();
    }

    // Update is called once per frame
    void Update()
    {
        

    }

    [PunRPC]
    void playerScore(int scoreincrement)
    {
        score += scoreincrement;
        Debug.Log(playerSetup.playername + score);

    }
}
